"""
snt_core — Sanket NakshaTech SNT binary CAD overlay format  v1.2

Public API
──────────
from snt_core import convert        # DXF → SNT  (main entry point)
from snt_core import SntReader      # low-level SNT reader
from snt_core import EntityType     # format constants
"""
from .snt_format import (
    EntityType,
    ColorMode,
    CREATOR,
    CREATOR_DESCRIPTION,
    validate_format_constants,
)
from .snt_writer import convert, ConvertResult
from .snt_reader import SntReader, CorruptFileError, VersionMismatchError, SntCRS
from .snt_report import write_report

__version__ = "1.2.0"
__author__  = "Sanket NakshaTech"

__all__ = [
    # Core conversion
    "convert",
    "ConvertResult",
    # Reader
    "SntReader",
    "SntCRS",
    # Exceptions
    "CorruptFileError",
    "VersionMismatchError",
    # Format
    "EntityType",
    "ColorMode",
    "CREATOR",
    "CREATOR_DESCRIPTION",
    "validate_format_constants",
    # Report
    "write_report",
]
